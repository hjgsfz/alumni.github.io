<?php
return [
	"Public"=>[
		"Photo"=>"http://img.badapple.top/Xlch/me/1.jpg",
		"CardBg"=>0,
		"Sign"=>"啥都不会的小白，只负责可爱"
	],
	"SocialAccount"=>[
		"QQ"=>"123456",
		"Weibo"=>"@黑化美学",
		"WeChat"=>"xlchmz"
	],
	"MyInfo"=>[
		"Birthday"=>"1999-2-2",
		"Gender"=>"1",
		"Motto"=>"不忘初心，方得始终。",
		"Constellation"=>"10",
		"Weight"=>"50",
		"Height"=>"160",
		"Character"=>[
			"0",
			"14",
			"30",
			"76",
			"78",
			"91",
			"99",
			"112"
		]
	],
	"LikeAndDislike"=>[
		"MyLikeThing"=>"学到东西 | 无忧无虑、什么事情都不用想 | 睡觉 | 不平凡的生活",
		"MyDislikeThing"=>"睡觉被惊醒(会很生气) | 停电 | 失约 | 欺骗 | 被嫉妒 | 被乱翻东西",
		"MyLikeItem"=>"食物：火锅丸子、川菜 | 物品：电子垃圾、高度集成/精密的东西",
		"MyDislikeItem"=>"没有做好的饭菜 | 不人性化的东西 | 发出异味或其他一切令人恶心的东西。",
		"BeGoodAt"=>"撸代码、宅在家"
	],
	"Location"=>[
		"Hometown"=>"中国 新疆维吾尔族自治区 伊犁 伊宁市",
		"NowLive"=>"中国 新疆维吾尔族自治区 乌鲁木齐市",
		"ZipCode"=>"830000"
	],
	"ContactMe"=>[
		"Phone"=>"17100000000",
		"Email"=>"me@qq-admin.cn"
	]
];