<!--
                                                       s&@@@@@@@@@@@#HX9hr:                                                  
                                                     ;GM@@@@@@@@@@@@@@@@#MBA85i                                              
                                                   .G@@@@@@@@@@@@@@@@@@@@@@@@@@M9:                                           
                                                  .&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#1                                          
                                                  h@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@, .;rssr,                                 
                                                ,sA@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@88B@@@@@#5                                
                                           .rHHA#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@:                               
                                           rB@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@i                               
                                            ,5B@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@X                                
                                               is&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@X#@@@@@@@A                                 
                                              ,s8@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Hr M@@@@@@@B.                                
                                              .,1&M@@@@@@@B#@@@@@@@@@@@@@@@@@@@8  ;@@@@@@@Hi.                :1991:          
           ,s9&81;.                             , sA@@@@@@BG8XHB#@@@@@@@@@@@@@HS: 5@@@@@@@@i           .;13XM@@#H#@H91;.     
       :s3&##A&#@@MA8Ss:                           .5HAX#@M@#BHHBM#@@@@@@@@#&Ah.. G@@@@@@@@G       ,s9AMM@@@Xh;. .i9@@@BX9hr,
.,ih9&B@@@#s.   :hM@@HBMBXSi.                         ..ShSM@@@@@@&XBHsHMHS: .:   3@@@@@@@@8  ,;19H#BG5irB@@H3.    r#@@@@@#@@
B@@@BB@@@@M;    5H@@@9 ,r3ABM&8Shsrii;;i;ir1h1.         .iM@@@@@@@@91, ;S,     sGXH@@@@@@@@X&HM@@@9:    X@@@@@#s   &@@@@@@G:s
@A;.hM@@@@@A   G@@@@@@h    s#@@AXXXGGXGX#@@#@@Bs  .r58&HM@@@@@@@@@@@#BA8Sr.  ,8@@#X@@@@@@Ariii5M@@H3.   8@@@@@@9   1B@@@@@@: 
H;  &@@@@@#h   &@@@@@Mi  ,G@@@@X      ;8#@#hrX@@X8M@@@@@@@@@@@@@@@@@@@@@@@M8SM@Hh.3@@@@M8.   .H@@@@@Hi   S@@@@@5    .SM@@@@S 
.   H@@@@X:    5@@@@M;   &@@@@@@9    s#@@@@#r.9@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#3:9@@@@@@9    :M@@@@@@s    1@@@@s      ,9#@@H 
   ,M@@#h      i@@@M;    3@@@@@Mi    X@@@@@@@M@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@8     ;M@@@@M,     rM@@i        :G@@i
   i@@X:       .B@M;     :#@@@@r     :#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@M.      ;M@@@X       :B@:          i&S
   hMh          GM;       X@@@h       S@@@@B#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@B8@@@@h        i#@@h        ,1              
   .,           ,:        s@@3        .H@@MB@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&A@@H          r#@;                        
                           HG          r@#r&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@S B@r           s9                         
                           ,            95G@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@h;S                                       
                                         3@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@i                                        
                                        r@@@@@@@H8@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@B.                                       
                                        H@@@@@@#:;@@@@@@@@@@@@@@@@@@@@@@@@@@B8@@@@@@@S                                       
                                     .;S@@@@@@@r ,M@@@@@@@@@@@@@@@@@@@@@@@@@X 9@@@@@@Mhi,                                    
     ..        ;831:             .iSXM@@@@@@@#s  .M@@@@@@@@@@@@@@@@@@@@@@@@@X  9@@@@@@@@#A91:             i8AA1        :h,   
    iBH.       .5B@#8i.      .iS&M@@@@@@@@@@Ai   i@@@@@@@@@@@@@@@@@@@@@@@@@@M,  hB@@@@@@@@@@@H8h;       ;9@@#s        :&@X,  
   .B@@H359GX&XGGM@@@@B9:,rSXM@@@@@@@@@@@B8s     h@@@@@@@@@@@@@@@@@@@@@@@@@@@s   .1GB@@@@@@@@@@@@BX5r,sA@@@@@MHAHBHHA&#@@@9  
    iG@@@@@@@@@@@@@@@@@@@#@@@@@@@@@@#H8h;        S@@@@@@@@@@@@@@@@@@@@@@@@@@#s       :19AM@@@@@@@@@@@#@@@@@@@@@@@@@@@@@@@h.  
      1B@@@@@@@@@@@@@@@@@@@@@@@@BXSr,           5#@@@@@@@@@@@@@@@@@@@@@@@@@@@#h          .ih8A#@@@@@@@@@@@@@@@@@@@@@@M@@8    
        ,,,595i:i1S9G&AHBMBAGSr,               9@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@3               :13XHM###MMBHAX95SXBMGii,     
　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
-->
<html>
	<head>
		<META http-equiv="content-type" content="text/html; charset=UTF-8">
		<title>XlchSafeSystem - 警告</title>
	</head>
	<body style="color:#fff;background:#000;text-align:center;">
		<img class="yaoyaole" src="http://img.badapple.top/cbyl/XlDf/148637373617285.png">
		<h1>XlchSafeSystem - 检测到大黑阔搞事情</h1><hr></hr>
			<p>系统已记录您的IP、账号，您的操作记录、以及个人信息已入库，如果再次尝试违法操作后果自负！</p>
			<p><img src="http://img.badapple.top/cbyl/hehe.gif"/></p>
		<h1>记录信息</h1><hr></hr>
		<div id="hehe">
		时间：<?=htmlspecialchars($log['time'])?><br>
		ＩＰ：<?=htmlspecialchars($log['ip'])?><br>
		ＵＡ：<?=htmlspecialchars($log['user_agent'])?><br>
		类型：<?=htmlspecialchars($log['method'])?><br>
		来路：<?=htmlspecialchars($log['request_url'])?><br>
		非法值：<pre><?=htmlspecialchars(print_r(['Key'=>$log['rkey'],'Value'=>$log['rdata'],'Data'=>$log['data'],'pregMatch'=>$log['pregmatch']],true));?></pre>
		</div>
		
		<h1>误报反馈</h1><hr></hr>
		<div id="SOHUCS" sid="XlchSafeSystem" style="max-width:1000px"></div>
		<script charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/changyan.js" ></script>
		<script type="text/javascript">
		window.changyan.api.config({
		appid: 'cysEq4p25',
		conf: 'prod_004b53ed707e976d0ac4ff2fda2c8503'
		});
		</script>
		<style>
		/* 震颤 */
		@-webkit-keyframes shake3{
			30%{-webkit-transform:translate(-3px,-5px);}
			60%{-webkit-transform:translate(6px,3px);}
		}
		@-moz-keyframes shake3{
			30%{-moz-transform:translate(-3px,-5px);}
			60%{-moz-transform:translate(6px,3px);}
		}
		@-ms-keyframes shake3{
			30%{-o-transform:translate(-3px,-5px);}
			60%{-o-transform:translate(6px,3px);}
		}
		@keyframes shake3{
			30%{transform:translate(-3px,-5px);}
			60%{transform:translate(6px,3px);}
		}
		/* 摇摇乐 */
		.yaoyaole{
			-webkit-animation:shake3 .3s steps(3) infinite;
			-moz-animation:shake3 .3s steps(3) infinite;
			-ms-animation:shake3 .3s steps(3) infinite;
			animation:shake3 .3s steps(3) infinite;max-width: 600px;
		}
		#hehe{
			text-align: initial;
		}
		</style>
			
		<!-- Your XlchPlayerKey -->
		<script>XlchKey="XlDf";</script>
		<!-- font-awesome 4.2.0 -->
		<link href="http://lib.baomitu.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!-- JQuery 2.2.4 -->
		<script src="http://lib.baomitu.com/jquery/2.2.4/jquery.min.js"></script>
		<!-- JQuery-mousewheel 3.1.9 -->
		<script src="http://lib.baomitu.com/jquery-mousewheel/3.1.9/jquery.mousewheel.min.js"></script>
		<!-- Scrollbar -->
		<script src="http://static.badapple.top/BadApplePlayer/js/scrollbar.js"></script>
		<!-- BadApplePlayer -->
		<script src="http://static.badapple.top/BadApplePlayer/Player.js"></script>
		<script src="http://lib.baomitu.com/jquery-color/2.1.2/jquery.color.min.js"></script>
		<script>
		var b=false;
		setInterval(function (){
			if(b){
			　　$("body").animate({
				　　backgroundColor:'#500000'
				},100);
			}else{
			　　$("body").animate({
				　　backgroundColor:'#000'
				},100);
			}
			b=!b;
		},100);
		var c=false;
		setInterval(function (){
			if(c){
			　　$("h1").animate({
				　　color:'#00FFDE'
				},500);
			}else{
			　　$("h1").animate({
				　　color:'#49FF00'
				},500);
			}
			c=!c;
		},100);
		</script>
		
	</body>
</html>