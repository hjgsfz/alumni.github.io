<?php
return <<<FlandreStudio_JSON
{
    "Ip": "localhost",
    "Port": "3306",
    "Username": "root",
    "Password": "123456",
    "Database": "root",
    "QZ": "xlch"
}
FlandreStudio_JSON;
?>