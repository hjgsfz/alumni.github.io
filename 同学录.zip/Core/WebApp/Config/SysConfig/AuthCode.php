<?php
return 'poweredbyxlch998998abcdefgabcdef';
?>