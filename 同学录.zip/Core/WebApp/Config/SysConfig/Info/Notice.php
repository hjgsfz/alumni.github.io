<?php /* 请务必不要改动这一行，否则会有安全隐患！ */ if(!defined('RootDir'))exit('Access Denied'); ?>
<span style="font-family:'Microsoft YaHei';font-size:32px;">Hello!</span> <span style="font-family:Microsoft YaHei;">欢迎您使用绚丽彩虹同学录。</span> 
<p>
	<br />
</p>
<p>
	<span style="font-family:Microsoft YaHei;">本程序开发者：<span style="color:#E53333;">绚丽彩虹</span></span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;">本程序策划者：<span style="color:#337FE5;">华梦流年</span></span><span style="font-family:Microsoft YaHei;"></span><span style="font-family:Microsoft YaHei;"></span><span style="font-family:Microsoft YaHei;"></span><span style="font-family:Microsoft YaHei;"></span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;"><br />
</span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;"><br />
</span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;">祝您使用愉快。</span> 
</p>