<?php
return <<<FlandreStudio_JSON
{
    "Public": {
        "Photo": "\/Upload\/Default\/Photo.png",
        "CardBg": 3,
        "Sign": "这家伙很怠惰，什么都没写！"
    },
    "SocialAccount": {
        "QQ": "408214421"
    }
}
FlandreStudio_JSON;
?>