<?php
$Core=[
	"Default"=>"Classmate",
	"Manager"=>"Manager"
];

$DefaultTemplate="Default";

$CookieName=[
	"Template"=>"xlch_template"
];

$IsWelcome=true;
$DefaultMod='Index';