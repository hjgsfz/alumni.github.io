<?php
//请勿编辑本文件！否则可能会导致各种迷の问题

//时间
$DateFormat = "Y-m-d";
$TimeFormat = "H:i:s";
$DatetimeFormat = "Y-m-d H:i:s";

//当前域名
$Domain=$_SERVER['HTTP_HOST'];
